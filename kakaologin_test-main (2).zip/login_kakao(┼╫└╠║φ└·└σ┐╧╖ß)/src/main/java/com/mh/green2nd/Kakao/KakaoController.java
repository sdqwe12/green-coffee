package com.mh.green2nd.Kakao;

import com.mh.green2nd.core.security.JwtTokenProvider;
import com.mh.green2nd.core.utils.ApiUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
public class KakaoController {
    private final KakaoService kakaoService;

    @GetMapping("/oauth2/kakao/callback")
    public ResponseEntity<?> callback(String code) {
        String jwt = kakaoService.login(code);
        return ResponseEntity.ok().header(JwtTokenProvider.HEADER, jwt)
                .body(ApiUtils.success(null));
    }
}