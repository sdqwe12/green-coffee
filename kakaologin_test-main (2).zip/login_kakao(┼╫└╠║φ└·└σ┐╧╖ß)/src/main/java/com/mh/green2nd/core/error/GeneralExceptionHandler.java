package com.mh.green2nd.core.error;

import com.mh.green2nd.core.utils.ApiUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GeneralExceptionHandler {

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleException(Exception e) {
        HttpStatus status;
        switch (e.getMessage()) {
            case "Bad Request":
                status = HttpStatus.BAD_REQUEST;
                break;
            case "Unauthorized":
                status = HttpStatus.UNAUTHORIZED;
                break;
            case "Forbidden":
                status = HttpStatus.FORBIDDEN;
                break;
            case "Not Found":
                status = HttpStatus.NOT_FOUND;
                break;
            case "Internal Server Error":
                status = HttpStatus.INTERNAL_SERVER_ERROR;
                break;
            default:
                status = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        ApiUtils.ApiResult<?> apiResult = ApiUtils.error(e.getMessage(), status);
        return new ResponseEntity<>(apiResult, status);
    }
}